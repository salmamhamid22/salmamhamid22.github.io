-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2024 at 04:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rh`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) NOT NULL,
  `code_auth` varchar(50) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `code_auth`, `nom`, `password`, `prenom`) VALUES
(1, 'johndoe123', 'Doe', '$2a$10$VSIXE9sKptZjJ3/mwmhubeNgpGQA8aBgFjxliZFWwGWLJcEhw5zZC', 'John'),
(2, 'admin9', 'aa', '$2a$10$LFGKH8lUYI0aQU8c.43iuOuu3vSe6n7vHUNCGAC.Sv8aGRyjldX0K', 'ya'),
(3, 'admin00', 'Doe', '$2a$10$nFVGAA3N75ynoSAEo7TyreUEUbCzIOQ4FAebIe/A/KOy2rSqhwEi6', 'John');

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `id` bigint(20) NOT NULL,
  `code_auth` varchar(50) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `grade` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `service` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`id`, `code_auth`, `nom`, `password`, `prenom`, `date`, `email`, `grade`, `post`, `service`, `telephone`) VALUES
(34, 'agent23', 'Tsu', 'agent123', 'Sainz', '2024-09-07', 'three@gmail.com', '2', 'Ingenieur', 'Production', '0672839993'),
(35, 'agent25', 'Comp', 'agent123', 'Pierre', '2024-09-07', 'ss@f.xg', '2', 'Administrateur', 'RH', '0672839993'),
(36, 'agent32', 'Merc', 'agent123', 'Enzo', '2024-09-04', 'enzo@gmail.com', '1', 'Administrateur', 'Production', '0672839993'),
(37, 'agent43', 'Mclar', 'agent123', 'Alb', '2024-09-11', 'stu.gh@gmail.com', '2', 'Ingenieur', 'Production', '0672839993');

-- --------------------------------------------------------

--
-- Table structure for table `avis`
--

CREATE TABLE `avis` (
  `id` bigint(20) NOT NULL,
  `date_examen` varchar(255) NOT NULL,
  `codeb` bigint(20) NOT NULL,
  `date_cloture` varchar(255) NOT NULL,
  `date_creation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `avis`
--

INSERT INTO `avis` (`id`, `date_examen`, `codeb`, `date_cloture`, `date_creation`) VALUES
(2, '2024-12-31', 1, '2024-12-30', '2024-12-30'),
(3, '2024-09-14', 1, '2024-09-14', '2024-09-19'),
(4, '2024-09-29', 1, '2024-09-26', '2024-09-23'),
(5, '2024-09-29', 1, '2024-09-26', '2024-09-23');

-- --------------------------------------------------------

--
-- Table structure for table `besoins`
--

CREATE TABLE `besoins` (
  `id` bigint(20) NOT NULL,
  `date_creation` varchar(255) NOT NULL,
  `nom_besoin` varchar(255) NOT NULL,
  `nombre_postes` int(11) NOT NULL,
  `poste` varchar(255) NOT NULL,
  `age_maximal` int(11) NOT NULL,
  `service` varchar(255) NOT NULL,
  `specialite` varchar(255) NOT NULL,
  `status` enum('PENDING','REJECTED','VALIDATED') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `besoins`
--

INSERT INTO `besoins` (`id`, `date_creation`, `nom_besoin`, `nombre_postes`, `poste`, `age_maximal`, `service`, `specialite`, `status`) VALUES
(1, '2024-09-19', 'Recrutement Technicien', 5, 'Technicien', 25, 'RH', 'Informatique', 'PENDING'),
(2, '2024-09-19', 's', 6, 'Administrateur', 40, 'Programmation', 'Informatique', 'PENDING'),
(3, '2024-09-19', 'Ask', 2, 'Technicien', 30, 'Programmation', 'Informatique', 'PENDING'),
(4, '2024-09-19', 'Anth', 2, 'Ingénieur', 30, 'Production', 'Elevage', 'PENDING'),
(5, '2024-09-19', 'Bs1', 2, 'Ingénieur', 29, 'Production', 'Elevage', 'PENDING'),
(6, '2024-09-23', 'Besoin 3', 3, 'Technicien', 30, 'Programmation', 'Informatique', 'PENDING'),
(7, '2024-09-23', 'Besoin', 4, 'Ingénieur', 32, 'Programmation', 'Informatique', 'PENDING');

-- --------------------------------------------------------

--
-- Table structure for table `candidat`
--

CREATE TABLE `candidat` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `candidature`
--

CREATE TABLE `candidature` (
  `id` bigint(20) NOT NULL,
  `code_avis` bigint(20) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `diplome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `poste_postule` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `sexe` varchar(255) NOT NULL,
  `statut` enum('ADMIS','EN_ATTENTE','NON_ADMIS') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidature`
--

INSERT INTO `candidature` (`id`, `code_avis`, `date_naissance`, `diplome`, `email`, `nom`, `poste_postule`, `prenom`, `sexe`, `statut`) VALUES
(8, 3, '2000-02-05', 'Master en Informatique', 'ro.an@example.com', 'An', 'Ingenieur', 'Ro', 'Feminin', 'ADMIS'),
(9, 4, '1990-02-05', 'Master en Droit', 'blue.an@example.com', 'An', 'Administrateur', 'Blue', 'Masculin', 'ADMIS'),
(10, 4, '1998-02-05', 'Master en Economie', 'red.an@example.com', 'Yen', 'Comptable', 'Red', 'Masculin', 'NON_ADMIS'),
(11, 3, '1968-02-05', 'Master en Economie', 'pink.an@example.com', 'Yen', 'Comptable', 'Pink', 'Feminin', 'ADMIS'),
(12, 3, '1968-02-05', 'Master en Economie', 'pink.an@example.com', 'Yen', 'Comptable', 'Purple', 'Feminin', 'EN_ATTENTE'),
(13, 3, '1998-02-05', 'Master en Ing', 'green.an@example.com', 'Won', 'Ingénieur', 'Green', 'Feminin', 'EN_ATTENTE'),
(14, 3, '1998-02-05', 'Master en Ing', 'green.an@example.com', 'Dollar', 'Ingénieur', 'Yellow', 'Feminin', 'EN_ATTENTE');

-- --------------------------------------------------------

--
-- Table structure for table `chefservices`
--

CREATE TABLE `chefservices` (
  `id` bigint(20) NOT NULL,
  `code_auth` varchar(50) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chefservices`
--

INSERT INTO `chefservices` (`id`, `code_auth`, `nom`, `password`, `prenom`) VALUES
(1, 'cs123', 'Doe', '$2a$10$uz2Hh4zAPv735z8VagiOguHynGxG4deH3wi.4/jsjDvZhka1zBWXC', 'John');

-- --------------------------------------------------------

--
-- Table structure for table `commission`
--

CREATE TABLE `commission` (
  `id` int(11) NOT NULL,
  `date_creation` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `convocations`
--

CREATE TABLE `convocations` (
  `id` bigint(20) NOT NULL,
  `is_sent` bit(1) NOT NULL,
  `message` varchar(255) NOT NULL,
  `recipient_email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `corps`
--

CREATE TABLE `corps` (
  `id` bigint(20) NOT NULL,
  `core` varchar(255) DEFAULT NULL,
  `grade` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `directeurs`
--

CREATE TABLE `directeurs` (
  `id` bigint(20) NOT NULL,
  `code_auth` varchar(50) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `directeurs`
--

INSERT INTO `directeurs` (`id`, `code_auth`, `nom`, `password`, `prenom`) VALUES
(1, 'doe123', 'Doe', '$2a$10$S83B98nU/2QON.Chif/Pve6mufWNn133KEXzlmg6G9fBlAAhJvfhS', 'John'),
(2, 'directeur', 'Doe', '$2a$10$rHs5of.uipnVdUzbV3UuO.Xgy8DHpza0LN9ze1O6zAcUPI0wgaNJq', 'John'),
(3, 'directeur1', 'Doe', '$2a$10$/b/dY4vuJ40yHH3bmwib0.w6YV1ukwdk9plR.VWUnfD/PyKWdWc6G', 'John'),
(4, 'directeur2', 'Doe', '$2a$10$YQvxECcpMGLhInOVrIcVEurozc/fWzlYb3h6JrLlxETBuVChXTSye', 'John');

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `id` bigint(20) NOT NULL,
  `contenu` varchar(255) DEFAULT NULL,
  `statut` bit(1) NOT NULL,
  `titre` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employe`
--

CREATE TABLE `employe` (
  `employe_specific_field` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `epreuves`
--

CREATE TABLE `epreuves` (
  `id` bigint(20) NOT NULL,
  `date` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jury`
--

CREATE TABLE `jury` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `liste`
--

CREATE TABLE `liste` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `membres`
--

CREATE TABLE `membres` (
  `id` bigint(20) NOT NULL,
  `code_auth` varchar(50) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `membres`
--

INSERT INTO `membres` (`id`, `code_auth`, `nom`, `password`, `prenom`) VALUES
(1, 'mb123', 'Doe', '$2a$10$eS0UTpZtlflXeSPox3gX7.SBz1ia2Bzo56VDzVo3s3Z30hoUPR.kC', 'John');

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE `note` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `option`
--

CREATE TABLE `option` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `preselection`
--

CREATE TABLE `preselection` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pv`
--

CREATE TABLE `pv` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`) VALUES
(11, 'Programmation'),
(12, 'Production'),
(15, 'RH');

-- --------------------------------------------------------

--
-- Table structure for table `specialites`
--

CREATE TABLE `specialites` (
  `id` bigint(20) NOT NULL,
  `nom` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `surveillance`
--

CREATE TABLE `surveillance` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `typepv`
--

CREATE TABLE `typepv` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKfl2mtu73ipj93mfxt4qkn90iq` (`code_auth`);

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKryu3dm0jmiy6xuuejiwi6v6ie` (`code_auth`);

--
-- Indexes for table `avis`
--
ALTER TABLE `avis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `besoins`
--
ALTER TABLE `besoins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidat`
--
ALTER TABLE `candidat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidature`
--
ALTER TABLE `candidature`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chefservices`
--
ALTER TABLE `chefservices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKh3hdfimgmleri6dagih0sl1p` (`code_auth`);

--
-- Indexes for table `commission`
--
ALTER TABLE `commission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `convocations`
--
ALTER TABLE `convocations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `corps`
--
ALTER TABLE `corps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `directeurs`
--
ALTER TABLE `directeurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKei8o31n6wbf2g8hs9p8bqe00i` (`code_auth`);

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employe`
--
ALTER TABLE `employe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `epreuves`
--
ALTER TABLE `epreuves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jury`
--
ALTER TABLE `jury`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `liste`
--
ALTER TABLE `liste`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKa8vguvndt9jsqwt9cmyh8vjio` (`code_auth`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `option`
--
ALTER TABLE `option`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `preselection`
--
ALTER TABLE `preselection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pv`
--
ALTER TABLE `pv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specialites`
--
ALTER TABLE `specialites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKnb3wae8k2jnr3qi8wpmjfgu53` (`nom`);

--
-- Indexes for table `surveillance`
--
ALTER TABLE `surveillance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typepv`
--
ALTER TABLE `typepv`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `avis`
--
ALTER TABLE `avis`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `besoins`
--
ALTER TABLE `besoins`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `candidat`
--
ALTER TABLE `candidat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `candidature`
--
ALTER TABLE `candidature`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `chefservices`
--
ALTER TABLE `chefservices`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `commission`
--
ALTER TABLE `commission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `convocations`
--
ALTER TABLE `convocations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `corps`
--
ALTER TABLE `corps`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `directeurs`
--
ALTER TABLE `directeurs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `document`
--
ALTER TABLE `document`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `epreuves`
--
ALTER TABLE `epreuves`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jury`
--
ALTER TABLE `jury`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `liste`
--
ALTER TABLE `liste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `membres`
--
ALTER TABLE `membres`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `option`
--
ALTER TABLE `option`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `preselection`
--
ALTER TABLE `preselection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pv`
--
ALTER TABLE `pv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `specialites`
--
ALTER TABLE `specialites`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `surveillance`
--
ALTER TABLE `surveillance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `typepv`
--
ALTER TABLE `typepv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employe`
--
ALTER TABLE `employe`
  ADD CONSTRAINT `FKa0msng2u8hnhgsyx94klp6q88` FOREIGN KEY (`id`) REFERENCES `agent` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
