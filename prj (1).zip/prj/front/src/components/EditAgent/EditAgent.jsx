import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import { TextField, Button } from '@mui/material';

const EditAgent = () => {
  const { id } = useParams();  // Get id from URL
  const [agent, setAgent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchAgent = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/agents/${id}`);
        setAgent(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching agent:', error);
        setError('Failed to load agent');
        setLoading(false);
      }
    };
    fetchAgent();
  }, [id]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setAgent(prevAgent => ({ ...prevAgent, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.put(`http://localhost:8080/agents/${id}`, agent);
      navigate('/agents');
    } catch (error) {
      console.error('Error updating agent:', error);
      setError('Failed to update agent');
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div>
      <h2>Edit Agent</h2>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Prénom"
          name="prenom"
          value={agent?.prenom || ''}
          onChange={handleChange}
          fullWidth
        />
        <TextField
          label="Nom"
          name="nom"
          value={agent?.nom || ''}
          onChange={handleChange}
          fullWidth
        />
        <TextField
          label="Grade"
          name="grade"
          value={agent?.grade || ''}
          onChange={handleChange}
          fullWidth
        />
        <TextField
          label="Service"
          name="service"
          value={agent?.service || ''}
          onChange={handleChange}
          fullWidth
        />
        <TextField
          label="Date d'embauche"
          name="date"
          value={agent?.date || ''}
          onChange={handleChange}
          fullWidth
        />
        <TextField
          label="E-mail"
          name="email"
          value={agent?.email || ''}
          onChange={handleChange}
          fullWidth
        />
        <TextField
          label="Numero de téléphone"
          name="telephone"
          value={agent?.telephone || ''}
          onChange={handleChange}
          fullWidth
        />
        <Button type="submit" variant="contained" color="primary">Save</Button>
      </form>
    </div>
  );
};

export default EditAgent;
