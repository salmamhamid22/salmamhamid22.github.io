import React, { useState, useEffect } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Checkbox, TextField, IconButton, Button } from '@mui/material';
import icons from '../importAllSvg';
import { useNavigate } from 'react-router-dom';
import './Besoins.css';

const Besoins = () => {
  const [besoins, setBesoins] = useState([]);
  const [dropdownVisible, setDropdownVisible] = useState(null);
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [checkedRows, setCheckedRows] = useState([]);
  const itemsPerPage = 5;
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch besoins from the API
    fetch('http://localhost:8080/besoins') // Update this URL if needed
      .then(response => response.json())
      .then(data => setBesoins(data))
      .catch(error => console.error('Error fetching besoins:', error));
  }, []);

  const handleSearchChange = (event) => {
    setSearch(event.target.value);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleStatusChange = (id, newStatus) => {
    setBesoins(prevBesoins =>
      prevBesoins.map(besoin =>
        besoin.id === id ? { ...besoin, status: newStatus } : besoin
      )
    );
    setDropdownVisible(null);
  };

  const filteredBesoins = besoins.filter(besoin =>
    besoin.nomBesoin.toLowerCase().includes(search.toLowerCase()) ||
    besoin.poste.toLowerCase().includes(search.toLowerCase())
  );

  const paginatedBesoins = filteredBesoins.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
  const totalPages = Math.ceil(filteredBesoins.length / itemsPerPage);

  const handleCheckboxChange = (event, id) => {
    event.stopPropagation();
    setCheckedRows(prevState =>
      prevState.includes(id) ? prevState.filter(rowId => rowId !== id) : [...prevState, id]
    );
  };

  const handleDropdownClick = (event, id) => {
    event.stopPropagation();
    setDropdownVisible(dropdownVisible === id ? null : id);
  };

  const getStatusClassName = (status) => {
    switch (status) {
      case 'Complété':
        return 'status-complete';
      case 'Suspendu':
        return 'status-suspendu';
      default:
        return '';
    }
  };

  return (
    <div className="besoins-container">
      <div className="top-bar">
        <h2>Besoins</h2>
        <div className="admin-info">
          <div className="admin-details">
            <span className="admin-name">Joe Ad</span>
            <span className="admin-role">Admin</span>
          </div>
          <img src={icons.services} alt="Avatar" className="admin-avatar" />
        </div>
      </div>
      <div className="search-and-filter">
        <div className="search-bar-container">
          <TextField
            placeholder="Search here..."
            variant="outlined"
            size="small"
            value={search}
            onChange={handleSearchChange}
            className="search-bar"
            InputProps={{
              startAdornment: <img src={icons.search} alt="Search Icon" className="search-icon" />
            }}
          />
        </div>
        <div className="filter-and-add">
          <Button
            variant="contained"
            color="primary"
            className="add-besoin-btn" // Use this class for custom styling
            onClick={() => navigate('/create-besoin')}
          >
            + Créer Besoin
          </Button>
        </div>
      </div>

      <TableContainer component={Paper} className="besoins-table">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell></TableCell>
              <TableCell>Nom Besoin</TableCell>
              <TableCell>Poste</TableCell>
              <TableCell>Service</TableCell>
              <TableCell>Spécialité</TableCell>
              <TableCell>Nombre de Postes</TableCell>
              <TableCell>Âge Max</TableCell>
              <TableCell>Date de Création</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedBesoins.map(besoin => (
              <TableRow
                key={besoin.id}
                className={checkedRows.includes(besoin.id) ? 'checked-row' : ''}
              >
                <TableCell>
                  <Checkbox
                    checked={checkedRows.includes(besoin.id)}
                    onChange={(event) => handleCheckboxChange(event, besoin.id)}
                  />
                </TableCell>
                <TableCell className="nom-cell">{besoin.nomBesoin}</TableCell>
                <TableCell className="content-cell">{besoin.poste}</TableCell>
                <TableCell className="content-cell">{besoin.service}</TableCell>
                <TableCell className="content-cell">{besoin.specialite}</TableCell>
                <TableCell className="content-cell">{besoin.nombrePostes}</TableCell>
                <TableCell className="content-cell">{besoin.ageMax}</TableCell>
                <TableCell className="content-cell">{besoin.dateCreation}</TableCell>
                <TableCell className={`content-cell status-cell ${getStatusClassName(besoin.status)}`}>
                  {besoin.status}
                </TableCell>
                <TableCell className="content-cell">
                  <IconButton onClick={(event) => handleDropdownClick(event, besoin.id)}>
                    <img src={icons.more} alt="More options" />
                  </IconButton>
                  {dropdownVisible === besoin.id && (
                    <div className="dropdown">
                      <div
                        className="dropdown-item"
                        onClick={() => handleStatusChange(besoin.id, 'Complété')}
                      >
                        Complété
                      </div>
                      <div
                        className="dropdown-item"
                        onClick={() => handleStatusChange(besoin.id, 'Suspendu')}
                      >
                        Suspendu
                      </div>
                    </div>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <div className="pagination">
        <span
          className="arrow"
          onClick={() => handlePageChange(currentPage - 1)}
          style={{ visibility: currentPage === 1 ? 'hidden' : 'visible' }}
        >
          {'<'}
        </span>
        {Array.from({ length: totalPages }, (_, i) => (
          <span
            key={i}
            className={currentPage === i + 1 ? 'active' : ''}
            onClick={() => handlePageChange(i + 1)}
          >
            {i + 1}
          </span>
        ))}
        <span
          className="arrow"
          onClick={() => handlePageChange(currentPage + 1)}
          style={{ visibility: currentPage === totalPages ? 'hidden' : 'visible' }}
        >
          {'>'}
        </span>
      </div>
    </div>
  );
};

export default Besoins;
