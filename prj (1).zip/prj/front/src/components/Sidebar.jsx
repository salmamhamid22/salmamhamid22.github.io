import React from 'react';
import { NavLink } from 'react-router-dom';
import { CiViewList } from "react-icons/ci";
import { FiBook } from "react-icons/fi";
import { GoCommentDiscussion } from "react-icons/go";
import { PiExam } from "react-icons/pi"; // Import the new Épreuve icon
import { MdOutlineDashboard } from "react-icons/md";
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import './Sidebar.css';
import icons from './importAllSvg';

const Sidebar = ({ isOpen, toggleSidebar }) => {

    const navigate = useNavigate(); // Initialize navigate

    const handleLogout = () => {
        // Perform logout logic (e.g., clear tokens, user state)
        // Then navigate to the login page
        toggleSidebar(); // Close the sidebar

        navigate('/login');
    };
    return (
        <div className={`sidebar ${isOpen ? 'open' : 'closed'}`}>
            <div className="logo">
                <img src={icons.ORMVASM} alt="Logo" />
            </div>
            <nav className="menu">
                <ul>
                    <li className='ds'>
                        <NavLink to="/dashboard" className={({ isActive }) => isActive ? "menu-item active" : "menu-item"}>
                            <MdOutlineDashboard className="menu-icon" />
                            Dashboard
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/agents" className={({ isActive }) => isActive ? "menu-item active" : "menu-item"}>
                            <img src={icons.agents} alt="Agents Icon" className="menu-icon" />
                            Agents
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/services" className={({ isActive }) => isActive ? "menu-item active" : "menu-item"}>
                            <img src={icons.services} alt="Services Icon" className="menu-icon" />
                            Services
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/besoins" className={({ isActive }) => isActive ? "menu-item active" : "menu-item"}>
                            <img src={icons.besoins} alt="Besoins Icon" className="menu-icon" />
                            Besoins
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/candidatures" className={({ isActive }) => isActive ? "menu-item active" : "menu-item"}>
                            <img src={icons.candidatures} alt="Candidatures Icon" className="menu-icon" />
                            Candidatures
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/calendrier" className={({ isActive }) => isActive ? "menu-item active" : "menu-item"}>
                            <img src={icons.calendrier} alt="Calendrier Icon" className="menu-icon" />
                            Calendrier
                        </NavLink>
                    </li>
                    
                    <li>
                        <NavLink to="/avisdetails" className={({ isActive }) => isActive ? "menu-item active" : "menu-item"}>
                            <GoCommentDiscussion className="menu-icon" />
                            Avis
                        </NavLink>
                    </li>
                </ul>
            </nav>
            <div className="footer">
                    <button className="logout-button" onClick={handleLogout}>
                        
                            Logout
                        </button>
                    </div>
        </div>
    );
}

export default Sidebar;
