import React, { useState } from 'react';
import { TextField, Button, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import axios from 'axios';

const AddChefForm = ({ selectedService, onClose }) => {
  const [formData, setFormData] = useState({
    codeAuth: '',
    password: '',
    prenom: '',
    nom: '',
    date: '',
    service: selectedService,
    post: '',
    grade: '',
    email: '',
    telephone: '',
    role: 'CHEFDESERVICE', // Default role
  });

  const [emailError, setEmailError] = useState('');
  const [telephoneError, setTelephoneError] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;

    if (name === 'email') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(value)) {
        setEmailError('Please enter a valid email address.');
      } else {
        setEmailError('');
      }
    }

    if (name === 'telephone') {
      const phoneRegex = /^\d{10}$/;
      if (!phoneRegex.test(value)) {
        setTelephoneError('Phone number must be exactly 10 digits.');
      } else {
        setTelephoneError('');
      }
    }

    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!emailError && !telephoneError) {
      axios.post('http://localhost:8080/agents', formData)
        .then(() => {
          alert('Chef de Service added successfully');
          onClose(); // Close the modal after successful addition
        })
        .catch((error) => {
          console.error('Error adding chef de service:', error);
        });
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ width: '90vw', maxWidth: '600px', margin: 'auto' }}>
      <TextField
        label="Code Auth*"
        name="codeAuth"
        value={formData.codeAuth}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Mot de passe*"
        name="password"
        type="password"
        value={formData.password}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Prénom*"
        name="prenom"
        value={formData.prenom}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Nom*"
        name="nom"
        value={formData.nom}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Date*"
        name="date"
        type="date"
        value={formData.date}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
        InputLabelProps={{ shrink: true }}
      />
      <TextField
        label="Service*"
        name="service"
        value={formData.service}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
        disabled
      />
      <TextField
        label="Poste*"
        name="post"
        value={formData.post}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Grade*"
        name="grade"
        value={formData.grade}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      <TextField
        label="Email*"
        name="email"
        type="email"
        value={formData.email}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      {emailError && <p style={{ color: 'red' }}>{emailError}</p>}
      <TextField
        label="Téléphone*"
        name="telephone"
        type="tel"
        value={formData.telephone}
        onChange={handleChange}
        fullWidth
        margin="normal"
        required
      />
      {telephoneError && <p style={{ color: 'red' }}>{telephoneError}</p>}
      <FormControl fullWidth margin="normal">
        <InputLabel>Rôle*</InputLabel>
        <Select
          name="role"
          value={formData.role}
          onChange={handleChange}
          disabled
        >
          <MenuItem value="CHEFDESERVICE">Chef de Service</MenuItem>
        </Select>
      </FormControl>
      <Button type="submit" variant="contained" color="primary" fullWidth>
        Ajouter Chef de Service
      </Button>
    </form>
  );
};

export default AddChefForm;
