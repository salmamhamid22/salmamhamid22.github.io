import React, { useState } from 'react';
import './LoginRegister.css';
import { FaUser, FaLock } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';

const LoginRegister = ({ onLogin }) => {
  const [codeAuth, setCodeAuth] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
        const response = await fetch('http://localhost:8080/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ codeAuth, password }),
        });

        if (response.ok) {
            const data = await response.json();
            const { token, role } = data;

            localStorage.setItem('authToken', token); // Store the token
            localStorage.setItem('codeAuth', codeAuth); // Store the codeAuth
            onLogin(role); // Notify App about login success
            navigate(redirectPath(role)); // Redirect based on role
        } else if (response.status === 401) {
            setError('Invalid credentials, please try again.');
        } else {
            setError('An unexpected error occurred. Please try again later.');
        }
    } catch (error) {
        setError('An unexpected error occurred. Please try again later.');
    } finally {
        setIsLoading(false);
    }
  };

  const redirectPath = (role) => {
    switch (role) {
        case 'ROLE_ADMIN':
            return '/dashboard';
        case 'ROLE_DIRECTEUR':
            return '/directeur-dashboard';
        case 'ROLE_CHEFSERVICE':
            return '/chefservice-dashboard';
        case 'ROLE_EMPLOYE':
            return '/employe-dashboard';
        case 'ROLE_MEMBRE':
            return '/membre-dashboard';
        default:
            return '/';
    }
  };

  return (
    <div className="login-page">
      <div className="wrapper">
        <div className="form-box login">
          <form onSubmit={handleSubmit}>
            <h1>Se connecter</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {isLoading && <p>Loading...</p>}
            <div className="input-box">
              <input
                type='text'
                placeholder="Code d'authentification"
                value={codeAuth}
                onChange={(e) => setCodeAuth(e.target.value)}
                required
              />
              <FaUser className='icon' />
            </div>
            <div className="input-box">
              <input
                type='password'
                placeholder='Mot de passe'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <FaLock className='icon' />
            </div>
            <div className="remember-forgot">
              <label><input type='checkbox' /> Se souvenir</label>
              <a href="/">Mot de passe oublié?</a>
            </div>
            <button type='submit' disabled={isLoading}>
              {isLoading ? 'Loading...' : 'Se connecter'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginRegister;
