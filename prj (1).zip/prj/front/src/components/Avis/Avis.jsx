import React, { useState, useEffect } from 'react';
import './Avis.css';
import { useNavigate } from 'react-router-dom';
import { TextField, FormControl, Grid, Button } from '@mui/material';
import icons from '../importAllSvg'; // Ensure this path is correct


const Avis = () => {
  const initialFormData = {
    dateExamen: '',
    dateCloture: '',
    besoinId: '',
    dateCreation: new Date().toISOString().split('T')[0], // Set default to today's date
  };

  const [formData, setFormData] = useState(initialFormData);
  const [besoins, setBesoins] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBesoins = async () => {
      try {
        const response = await fetch('http://localhost:8080/besoins');
        const data = await response.json();
        setBesoins(data);
      } catch (error) {
        console.error('Error fetching besoins:', error);
      }
    };

    fetchBesoins();
  }, []);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Ensure besoinId is converted to a number and assigned to codeB
    const dataToSend = {
      ...formData,
      codeB: Number(formData.besoinId),
    };

    try {
      const response = await fetch('http://localhost:8080/avis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataToSend),
      });

      if (response.ok) {
        const createdAvis = await response.json();
        navigate('/avisdetails', { state: { avis: createdAvis } });
      } else {
        console.error('Failed to save data:', await response.text());
      }
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  const handleCancel = () => {
    setFormData(initialFormData);
  };

  return (
    <div className="avis-container">
      <div className="top-bar">
        <h2>Avis</h2>
        <div className="admin-info">
          <div className="admin-details">
            <span className="admin-name">Joe Ad</span>
            <span className="admin-role">Admin</span>

          </div>
          <img src={icons.services} alt="Avatar" className="admin-avatar" />

        </div>
      </div>
      <div className='the-form'>
        <div className="navbar">
          <h2>Créer Avis</h2>
        </div>
        <form onSubmit={handleSubmit} className="avis-form">
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <FormControl fullWidth variant="outlined" className="form-field">
                <TextField
                  name="besoinId"
                  value={formData.besoinId}
                  onChange={handleChange}
                  label="ID BESOIN"
                  variant="outlined"
                />
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <FormControl fullWidth variant="outlined" className="form-field">
                <TextField
                  name="dateCreation"
                  value={formData.dateCreation}
                  InputProps={{
                    readOnly: true,
                  }}
                  label="DATE DE CRÉATION"
                  variant="outlined"
                  type="date"
                  InputLabelProps={{ shrink: true }}
                />
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <FormControl fullWidth variant="outlined" className="form-field">
                <TextField
                  name="dateExamen"
                  value={formData.dateExamen}
                  onChange={handleChange}
                  label="DATE D'EXAMEN"
                  variant="outlined"
                  type="date"
                  InputLabelProps={{ shrink: true }}
                />
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <FormControl fullWidth variant="outlined" className="form-field">
                <TextField
                  name="dateCloture"
                  value={formData.dateCloture}
                  onChange={handleChange}
                  label="DATE DE CLOTURE"
                  variant="outlined"
                  type="date"
                  InputLabelProps={{ shrink: true }}
                />
              </FormControl>
            </Grid>
          </Grid>
          <div className="form-buttons">
            <Button type="submit" variant="contained" color="primary" className="submit-button">Sauvegarder</Button>
            <Button type="button" variant="outlined" color="secondary" className="submit-button" onClick={handleCancel}>Annuler</Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Avis;
