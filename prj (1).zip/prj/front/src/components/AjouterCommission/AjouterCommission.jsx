import React from 'react';

const AjouterCommission = () => {
  return (
    <div>
      <h2>Ajouter Commission</h2>
    </div>
  );
};

export default AjouterCommission;
