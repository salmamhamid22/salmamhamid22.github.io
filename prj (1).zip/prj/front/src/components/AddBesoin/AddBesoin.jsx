import React, { useState, useEffect } from 'react';
import { Button, TextField, MenuItem, Select, InputLabel, FormControl } from '@mui/material';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './AddBesoin.css';


const AddBesoin = () => {
  const [nomBesoin, setNomBesoin] = useState('');
  const [poste, setPoste] = useState('');
  const [service, setService] = useState('');
  const [specialite, setSpecialite] = useState('');
  const [nombrePostes, setNombrePostes] = useState('');
  const [ageMax, setAgeMax] = useState('');
  const [dateCreation, setDateCreation] = useState(new Date().toISOString().split('T')[0]);
  const [services, setServices] = useState([]);
  
  const navigate = useNavigate(); // Initialize navigate function

  useEffect(() => {
    // Fetch services from the API
    fetch('http://localhost:8080/services') // Update this URL if needed
      .then(response => response.json())
      .then(data => setServices(data))
      .catch(error => console.error('Error fetching services:', error));
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();

    const newBesoins = {
      nomBesoin,
      poste,
      service,
      specialite,
      nombrePostes,
      ageMax,
      dateCreation,
      status: 'PENDING' // Set status to PENDING by default
    };

    // Send POST request to the API
    fetch('http://localhost:8080/besoins', { // Update this URL if needed
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newBesoins)
    })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
      navigate('/besoins'); // Redirect to the besoins page
    })
    .catch(error => console.error('Error:', error));
  };

  return (
    <div className="add-besoin-container">
      <form onSubmit={handleSubmit} className="add-besoin-form">
        <h2>Ajouter un Besoin</h2>
        <TextField
          label="Nom du Besoin"
          value={nomBesoin}
          onChange={(e) => setNomBesoin(e.target.value)}
          fullWidth
          required
          margin="normal"
        />
        <FormControl fullWidth required margin="normal">
          <InputLabel>Poste</InputLabel>
          <Select
            value={poste}
            onChange={(e) => setPoste(e.target.value)}
          >
            <MenuItem value="Administrateur">Administrateur</MenuItem>
            <MenuItem value="Ingénieur">Ingénieur</MenuItem>
            <MenuItem value="Technicien">Technicien</MenuItem>
          </Select>
        </FormControl>
        <FormControl fullWidth required margin="normal">
          <InputLabel>Service</InputLabel>
          <Select
            value={service}
            onChange={(e) => setService(e.target.value)}
          >
            {services.map((service) => (
              <MenuItem key={service.id} value={service.name}>
                {service.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <TextField
          label="Spécialité"
          value={specialite}
          onChange={(e) => setSpecialite(e.target.value)}
          fullWidth
          required
          margin="normal"
        />
        <TextField
          label="Nombre de Postes"
          type="number"
          value={nombrePostes}
          onChange={(e) => setNombrePostes(e.target.value)}
          fullWidth
          required
          margin="normal"
        />
        <TextField
          label="Âge Maximal"
          type="number"
          value={ageMax}
          onChange={(e) => setAgeMax(e.target.value)}
          fullWidth
          required
          margin="normal"
        />
        <TextField
          label="Date de Création"
          type="date"
          value={dateCreation}
          onChange={(e) => setDateCreation(e.target.value)}
          fullWidth
          InputLabelProps={{
            shrink: true,
          }}
          required
          margin="normal"
        />
        <Button type="submit" variant="contained">
          Enregistrer
        </Button>
      </form>
    </div>
  );
};

export default AddBesoin;
