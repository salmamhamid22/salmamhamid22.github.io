import React, { useState } from 'react';
import { TextField, Button } from '@mui/material';
import axios from 'axios';

const AddService = ({ onClose }) => {
  const [name, setName] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();

    axios.post('http://localhost:8080/services', { name })
      .then(() => {
        alert('Service added successfully');
        onClose();  // Close the modal after successful addition
      })
      .catch((error) => {
        console.error('Error adding service:', error);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        label="Service Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        fullWidth
        margin="normal"
        required
      />
      <Button type="submit" variant="contained" color="primary">
        Add Service
      </Button>
    </form>
  );
};

export default AddService;
