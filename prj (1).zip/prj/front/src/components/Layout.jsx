import React from 'react';
import Sidebar from './Sidebar';

const Layout = ({ children, isSidebarOpen, toggleSidebar }) => {
  return (
    <div className="app d-flex">
      <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />
      <div className={`content flex-grow-1 ${isSidebarOpen ? 'shifted' : ''}`}>
        {children}
      </div>
    </div>
  );
};

export default Layout;
