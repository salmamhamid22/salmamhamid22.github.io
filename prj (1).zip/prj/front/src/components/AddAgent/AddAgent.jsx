import React, { useState, useEffect } from 'react';
import { Button, TextField, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './AddAgent.css'; // Ensure this file includes the styles provided below

const AddAgent = () => {
  const [formData, setFormData] = useState({
    codeAuth: '',
    password: '',
    prenom: '',
    nom: '',
    date: '',
    service: '',
    post: '',
    grade: '',
    email: '',
    telephone: '',
  });
  const [emailError, setEmailError] = useState('');
  const [telephoneError, setTelephoneError] = useState('');
  const [services, setServices] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    // Fetch services from the API
    fetch('http://localhost:8080/services') // Update this URL if needed
      .then(response => response.json())
      .then(data => setServices(data))
      .catch(error => console.error('Error fetching services:', error));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === 'email') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      setEmailError(!emailRegex.test(value) ? 'Please enter a valid email address.' : '');
    }

    if (name === 'telephone') {
      const phoneRegex = /^\d{10}$/;
      setTelephoneError(!phoneRegex.test(value) ? 'Phone number must be exactly 10 digits.' : '');
    }

    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!emailError && !telephoneError) {
      // Prepare form data for submission
      const newAgent = { ...formData, role: 'CHEFDESERVICE' }; // Default role

      fetch('http://localhost:8080/agents', { // Update this URL if needed
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newAgent),
      })
        .then(response => response.json())
        .then(data => {
          console.log('Success:', data);
          navigate('/agents'); // Redirect to agents page
        })
        .catch(error => console.error('Error:', error));
    }
  };

  return (
    <div className="add-agent-container">
      <form onSubmit={handleSubmit} className="add-agent-form">
        <h2>Ajouter un Agent</h2>
        <div className="form-row">
          <TextField
            label="Code Auth*"
            name="codeAuth"
            value={formData.codeAuth}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
          <TextField
            label="Mot de passe*"
            name="password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
        </div>
        <div className="form-row">
          <TextField
            label="Prénom*"
            name="prenom"
            value={formData.prenom}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
          <TextField
            label="Nom*"
            name="nom"
            value={formData.nom}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
        </div>
        <div className="form-row">
          <TextField
            label="Date*"
            name="date"
            type="date"
            value={formData.date}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            InputLabelProps={{ shrink: true }}
            variant="outlined"
            className="textfield-custom"
          />
          <FormControl fullWidth required margin="normal">
            <InputLabel>Service*</InputLabel>
            <Select
              name="service"
              value={formData.service}
              onChange={handleChange}
              variant="outlined"
              className="select-custom"
            >
              {services.map((service) => (
                <MenuItem key={service.id} value={service.name}>
                  {service.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>
        <div className="form-row">
          <TextField
            label="Poste*"
            name="post"
            value={formData.post}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
          <TextField
            label="Grade*"
            name="grade"
            value={formData.grade}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
        </div>
        <div className="form-row">
          <TextField
            label="Email*"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
          {emailError && <p className="error-text">{emailError}</p>}
          <TextField
            label="Téléphone*"
            name="telephone"
            type="tel"
            value={formData.telephone}
            onChange={handleChange}
            fullWidth
            required
            margin="normal"
            variant="outlined"
            className="textfield-custom"
          />
          {telephoneError && <p className="error-text">{telephoneError}</p>}
        </div>
        <Button type="submit" variant="contained" className="submit-btn">
          Soumettre
        </Button>
      </form>
    </div>
  );
};

export default AddAgent;
