import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Agents/Agents.css';
import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TextField,
  Menu,
  MenuItem,
  IconButton,
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import icons from '../importAllSvg'; // Ensure this path is correct

const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
};

const AvisDetails = () => {
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [avis, setAvis] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedAvisId, setSelectedAvisId] = useState(null);

  const itemsPerPage = 6;
  const navigate = useNavigate();
  const debouncedSearch = useDebounce(search, 500);

  useEffect(() => {
    const fetchAvisWithBesoin = async () => {
      try {
        // Fetch all Avis
        const response = await axios.get('http://localhost:8080/avis');
        const avisData = response.data;
  
        // Create an array of promises to fetch each Besoin by its id (codeB)
        const besoinPromises = avisData.map(avisItem =>
          axios.get(`http://localhost:8080/besoins/${avisItem.codeB}`).catch(() => null) // Gracefully handle errors
        );
  
        // Resolve all Besoin requests
        const besoinResponses = await Promise.all(besoinPromises);
  
        // Combine each Avis with its corresponding Besoin (if available)
        const avisWithBesoin = avisData.map((avisItem, index) => ({
          ...avisItem,
          besoin: besoinResponses[index] ? besoinResponses[index].data : null, // Attach Besoin data or null if error
        }));
  
        setAvis(avisWithBesoin);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching Avis or Besoin:', error);
        setError('Failed to load data');
        setLoading(false);
      }
    };
  
    fetchAvisWithBesoin();
  }, []);
  

  const handleSearchChange = (event) => {
    setSearch(event.target.value);
  };

  const handleDelete = (id) => {
    // Add delete logic here (e.g., axios.delete(`/avis/${id}`))
    console.log('Delete action for id:', id);
    setAnchorEl(null); // Close the menu after deletion
  };

  const handleModify = (id) => {
    navigate(`/avis/${id}/edit`);
    setAnchorEl(null); // Close the menu after navigating
  };

  const handleMenuOpen = (event, id) => {
    setAnchorEl(event.currentTarget);
    setSelectedAvisId(id); // Store the selected Avis ID for further actions
  };

  const handleMenuClose = () => {
    setAnchorEl(null); // Close the menu
  };

  const filteredAvis = avis.filter(avisItem => {
    const lowerCaseSearch = debouncedSearch.toLowerCase();
    return (
      avisItem.codeB.toString().includes(lowerCaseSearch) ||
      avisItem.dateCreation?.toLowerCase().includes(lowerCaseSearch) ||
      avisItem.dateCloture?.toLowerCase().includes(lowerCaseSearch) ||
      avisItem.dateExamen?.toLowerCase().includes(lowerCaseSearch)
    );
  });

  const totalPages = Math.ceil(filteredAvis.length / itemsPerPage);
  const paginatedAvis = filteredAvis.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const renderPagination = () => {
    const pagination = [];
    const maxVisiblePages = 5;

    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    if (startPage > 1) {
      pagination.push(
        <span key="start" onClick={() => setCurrentPage(1)}>1</span>
      );
      if (startPage > 2) {
        pagination.push(<span key="start-ellipsis">...</span>);
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      pagination.push(
        <span
          key={i}
          className={currentPage === i ? 'active' : ''}
          onClick={() => setCurrentPage(i)}
        >
          {i}
        </span>
      );
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        pagination.push(<span key="end-ellipsis">...</span>);
      }
      pagination.push(
        <span key="end" onClick={() => setCurrentPage(totalPages)}>{totalPages}</span>
      );
    }

    return pagination;
  };

  return (
    <div className="agent-container">
      <div className="top-bar">
        <h2>Avis</h2>
        <div className="admin-info">
          <div className="admin-details">
            <span className="admin-name">Joe Ad</span>
            <span className="admin-role">Admin</span>
          </div>
          <img src={icons.services} alt="Avatar" className="admin-avatar" />
        </div>
      </div>

      <div className="search-and-filter">
        <div className="search-bar-container">
          <TextField
            placeholder="Search here..."
            variant="outlined"
            size="small"
            value={search}
            onChange={handleSearchChange}
            className="search-bar"
            InputProps={{
              startAdornment: <img src={icons.search} alt="Search Icon" className="search-icon" />
            }}
          />
        </div>
        <Button
          variant="contained"
          color="primary"
          className="add-agent-btn"
          onClick={() => navigate('/avis')} // Adjust this route for creating a new avis
        >
          + Créer Avis
        </Button>
      </div>

      {error ? (
        <div className="error-message">{error}</div>
      ) : loading ? (
        <div className="loading-message">Loading...</div>
      ) : filteredAvis.length === 0 ? (
        <div className="empty-message">No avis found</div>
      ) : (
        <TableContainer component={Paper} className="agent-table-container">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Id Avis</TableCell>
                <TableCell>Id Besoin</TableCell>
                <TableCell>Date de Création</TableCell>
                <TableCell>Date de Clôture</TableCell>
                <TableCell>Date d'Examen</TableCell>
                <TableCell>Nom Besoin</TableCell>
                <TableCell>Service</TableCell>
                <TableCell>Spécialité</TableCell>
                <TableCell>Nombre de Postes</TableCell>
                <TableCell>Âge Maximal</TableCell>
                <TableCell>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedAvis.map((avisItem) => (
                <TableRow key={avisItem.id}>
                <TableCell>#{avisItem.id}</TableCell>
                <TableCell>#{avisItem.codeB}</TableCell>
                <TableCell>{avisItem.dateCreation}</TableCell>
                <TableCell>{avisItem.dateCloture}</TableCell>
                <TableCell>{avisItem.dateExamen}</TableCell>
                {/* Display the Besoin attributes */}
                <TableCell>{avisItem.besoin?.nomBesoin || 'N/A'}</TableCell>
                <TableCell>{avisItem.besoin?.service || 'N/A'}</TableCell>
                <TableCell>{avisItem.besoin?.specialite || 'N/A'}</TableCell>
                <TableCell>{avisItem.besoin?.nombrePostes || 'N/A'}</TableCell>
                <TableCell>{avisItem.besoin?.ageMax || 'N/A'}</TableCell>
                <TableCell>
                    <IconButton onClick={(event) => handleMenuOpen(event, avisItem.id)}>
                      <MoreVertIcon />
                    </IconButton>
                    {/* Dropdown Menu for Modify and Delete */}
                    <Menu
                      anchorEl={anchorEl}
                      open={Boolean(anchorEl) && selectedAvisId === avisItem.id}
                      onClose={handleMenuClose}
                    >
                      <MenuItem onClick={() => handleModify(avisItem.id)}>Modifier</MenuItem>
                      <MenuItem onClick={() => handleDelete(avisItem.id)}>Supprimer</MenuItem>
                    </Menu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <div className="pagination">{renderPagination()}</div>
    </div>
  );
};

export default AvisDetails;
