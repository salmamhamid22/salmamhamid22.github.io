import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import axios from 'axios';

const COLORS = ['#FF6F61', '#6B5B95'];

const PieChartComponent = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        // Fetch data from backend
        axios.get('http://localhost:8080/candidatures/gender-count')
            .then(response => {
                const { Feminin, Masculin } = response.data;
                setData([
                    { name: 'Feminin', value: Feminin },
                    { name: 'Masculin', value: Masculin }
                ]);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }, []);

    return (
        <div className="card" style={{height:94.5 + "%"}}>
            <div className="card-body">
                <h3 className="chart-title">Candidats</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie
                            data={data}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={120}
                            fill="#8884d8"
                            label
                        >
                            {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default PieChartComponent;
