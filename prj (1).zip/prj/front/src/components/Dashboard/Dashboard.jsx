import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Dashboard.css';
import icons from '../importAllSvg';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { Calendar, Badge } from 'antd';
import { FileDoneOutlined } from '@ant-design/icons';
import { scaleSequential } from 'd3-scale';
import { interpolateRainbow } from 'd3-scale-chromatic';
import { TextField } from '@mui/material';
import moment from 'moment';
import PieChartComponent from '../PieChartComponent/PieChartComponent';


const getColor = (index, total) => {
    const colorScale = scaleSequential(interpolateRainbow).domain([0, total]);
    return colorScale(index);
};

const lineChartData = [
    { name: 'Jan', thisWeek: 40, lastWeek: 24 },
    { name: 'Feb', thisWeek: 30, lastWeek: 14 },
    { name: 'Mar', thisWeek: 20, lastWeek: 98 },
    { name: 'Apr', thisWeek: 27, lastWeek: 39 },
    { name: 'May', thisWeek: 18, lastWeek: 48 },
    { name: 'Jun', thisWeek: 23, lastWeek: 38 },
    { name: 'Jul', thisWeek: 34, lastWeek: 43 },
];

const barChartData = [
    { name: 'Mon', thisWeek: 40, lastWeek: 24 },
    { name: 'Tue', thisWeek: 30, lastWeek: 13 },
    { name: 'Wed', thisWeek: 20, lastWeek: 98 },
    { name: 'Thu', thisWeek: 27, lastWeek: 39 },
    { name: 'Fri', thisWeek: 18, lastWeek: 48 },
    { name: 'Sat', thisWeek: 23, lastWeek: 38 },
    { name: 'Sun', thisWeek: 34, lastWeek: 43 },
];

const barChartDataSpecialite = [
    { name: 'Droit', value: 3 },
    { name: 'Technicien informatique', value: 2 },
    { name: 'Wed', value: 7 },
    { name: 'Thu', value: 5 },
    { name: 'Technicien informatique', value: 4 },
    { name: 'Sat', value: 8 },
    { name: 'Sun', value: 4 },
    { name: 'Sun', value: 4 },
    { name: 'Sun', value: 4 },
    { name: 'Sun', value: 4 },
    { name: 'Sun', value: 4 }
];

const COLORS = ['#278260', '#FF865C'];

const pieChartData = [
    { name: 'F', value: 1245 },
    { name: 'M', value: 1356 },
];

const Dashboard = () => {
    const navigate = useNavigate(); // Initialize useNavigate
    const [events, setEvents] = useState([]);
    const [agentCount, setAgentCount] = useState(0);
    const [serviceCount, setServiceCount] = useState(0);
    const [candidatureCount, setCandidatureCount] = useState(0);


    useEffect(() => {
        // Fetch events from localStorage
        const storedEvents = localStorage.getItem('events');
        if (storedEvents) {
            setEvents(JSON.parse(storedEvents));
        }

        const fetchCounts = async () => {
            try {
                const [agentResponse, serviceResponse, candidatureResponse] = await Promise.all([
                    fetch('http://localhost:8080/agents/count'),
                    fetch('http://localhost:8080/services/count'),
                    fetch('http://localhost:8080/candidatures/count'),
                ]);

                if (!agentResponse.ok) {
                    throw new Error(`Agent API error: ${agentResponse.status}`);
                }
                if (!serviceResponse.ok) {
                    throw new Error(`Service API error: ${serviceResponse.status}`);
                }
                if (!candidatureResponse.ok) {
                    throw new Error(`Candidature API error: ${candidatureResponse.status}`);
                }

                // Directly set the counts from the responses
                const agentData = await agentResponse.text(); // Read response as text
                const serviceData = await serviceResponse.text(); // Read response as text
                const candidatureData = await candidatureResponse.text(); // Read response as text

                setAgentCount(Number(agentData)); // Convert text to number
                setServiceCount(Number(serviceData)); // Convert text to number
                setCandidatureCount(Number(candidatureData)); // Convert text to number

            } catch (error) {
                console.error('Error fetching counts:', error);
            }
        };        

        fetchCounts();
    }, []);

    const dateCellRender = (value) => {
        const currentDate = value.format('YYYY-MM-DD');
        const dayEvents = events.filter(event => moment(event.start).format('YYYY-MM-DD') === currentDate);

        return (
            <div className="event-day">
                {dayEvents.map((event, index) => (
                    <div key={index} className="event-indicator" style={{ backgroundColor: event.color }}></div>
                ))}
            </div>
        );
    };

    const handleCreateAvis = () => {
        navigate('/avis'); // Navigate to Avis component
    };

    const handleCreateEpreuve = () => {
        navigate('/epreuve'); // Navigate to Epreuve component
    };

    const handleAvatarClick = () => {
        navigate('/profile'); // Navigate to Profile component
    };

    return (
        <div className="background d-flex flex-column flex-md-row">
            <div className="flex-grow-1 p-3">
                <div className="dashboard">
                <div className="top-bar">
                    <h2>Dashboard</h2>
                    <div className="admin-info">
                    <div className="admin-details">
                        <span className="admin-name">Joe Ad</span>
                        <span className="admin-role">Admin</span>

                    </div>
                    <img src={icons.services} alt="Avatar" className="admin-avatar" />
                    </div>
                </div>
                        <div className="row stats-cards mb-3 align-items-center">
                            <div className="col-md-4 mb-3">
                                <div className="card stats-card-short">
                                    <div className="card-body d-flex justify-content-between align-items-center flex-wrap">
                                        <div className="stat-item">
                                            <div className="icon-circle agent-icon-color mx-auto">
                                                <img src={icons.agents} alt="Agent Icon" className="stat-icon" />
                                            </div>
                                            
                                            <div className="ml-3">
                                                <h5 className="mb-1">Agents</h5> 
                                                <p className="mb-0 font-weight-bold">{agentCount}</p> 
                                            </div>
                                        </div>
                                        
                                        <div className="stat-item">
                                            <div className="icon-circle service-icon-color mx-auto">
                                                <img src={icons.services} alt="Services Icon" className="stat-icon" />
                                            </div>
                                            <div className="ml-3">
                                                <h5 className="mb-1">Services</h5>
                                                <p className="mb-0 font-weight-bold">{serviceCount}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4 mb-3">
                                <div className="card stats-card-short">
                                    <div className="card-body d-flex align-items-center">
                                        <div className="icon-circle bg-light-purple">
                                            <FileDoneOutlined className="stat-icon" />
                                        </div>
                                        <div className="ml-3">
                                            <h5 className="mb-0">Candidatures</h5>
                                            <p className="mb-0 font-weight-bold">{candidatureCount}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4 mb-3">
                                <div className="button-container">
                                    <button className="btn btn-success w-50 mb-1 radius" onClick={handleCreateAvis}>+ Créer Avis</button>
                                    <button className="btn btn-outline-success w-50 radius" onClick={handleCreateEpreuve}>+ Créer Besoin</button>
                                </div>
                            </div>
                        </div>
                        <div className="row mb-4 charts">
                            <div className="col-md-5 mb-4">
                                <div className="card h-100 calendrier-card">
                                    <div className="card-body">
                                        <h3 className="chart-title">Calendrier Recrutement</h3>
                                        <Calendar fullscreen={false} dateCellRender={dateCellRender} />
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-5">
                                <PieChartComponent />
                            </div> 
                        </div>
                 {/*  <div className="row mb-4">
                        <div className="col-md-12">
                            <div className="card">
                                <div className="card-body">
                                    <h3 className="chart-title">Pourcentages de candidatures par spécialité</h3>
                                    <ResponsiveContainer width="100%" height={400}>
                                        <BarChart data={barChartDataSpecialite} layout="vertical" margin={{ top: 5, right: 5, left: 25, bottom: 1 }}>
                                            <CartesianGrid strokeDasharray="3 3" />
                                            <XAxis type="number" />
                                            <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} width={60} />
                                            <Tooltip />
                                            <Bar dataKey="value">
                                                {barChartDataSpecialite.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={getColor(index, barChartDataSpecialite.length)} />
                                                ))}
                                            </Bar>
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>
                    </div>*/}  
                </div>
            </div>
        </div>
    );
}

export default Dashboard;
