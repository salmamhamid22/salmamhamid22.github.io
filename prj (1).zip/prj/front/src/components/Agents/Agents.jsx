import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import './Agents.css';
import { useNavigate } from 'react-router-dom';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Checkbox, 
  IconButton, 
  Button, 
  TextField, 
  Menu, 
  MenuItem, 
  Checkbox as MuiCheckbox, 
  FormControlLabel 
} from '@mui/material';
import icons from '../importAllSvg';  // Ensure this path is correct

const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value);
  
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  
  return debouncedValue;
};

const Agent = () => {
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedAgents, setSelectedAgents] = useState(new Set());
  const [selectedGrade, setSelectedGrade] = useState([]);
  const [selectedService, setSelectedService] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectAll, setSelectAll] = useState(false);
  const [contextMenuAnchor, setContextMenuAnchor] = useState(null);
  const [selectedAgentIndex, setSelectedAgentIndex] = useState(null);
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const itemsPerPage = 6;
  const navigate = useNavigate();
  const debouncedSearch = useDebounce(search, 500);

  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await axios.get('http://localhost:8080/agents');
        setAgents(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching agents:', error);
        setError('Failed to load agents');
        setLoading(false);
      }
    };
    fetchAgents();
  }, []);

  const uniqueGrades = useMemo(() => {
    return [...new Set(agents.map(agent => agent.grade).filter(Boolean))];
  }, [agents]);

  const uniqueServices = useMemo(() => {
    return [...new Set(agents.map(agent => agent.service).filter(Boolean))];
  }, [agents]);

  const handleGradeChange = (event) => {
    const value = event.target.value;
    setSelectedGrade(prev => 
      prev.includes(value) ? prev.filter(grade => grade !== value) : [...prev, value]
    );
  };

  const handleServiceChange = (event) => {
    const value = event.target.value;
    setSelectedService(prev => 
      prev.includes(value) ? prev.filter(service => service !== value) : [...prev, value]
    );
  };

  const handleFilterClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setAnchorEl(null);
  };

  const handleSearchChange = (event) => {
    setSearch(event.target.value);
  };
  
  

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleSelectChange = (index) => {
    const uniqueKey = index + (currentPage - 1) * itemsPerPage;
    setSelectedAgents(prev => {
      const newSelected = new Set(prev);
      if (newSelected.has(uniqueKey)) {
        newSelected.delete(uniqueKey);
      } else {
        newSelected.add(uniqueKey);
      }
      return newSelected;
    });
  };

  const handleSelectAllChange = (event) => {
    const isChecked = event.target.checked;
    setSelectAll(isChecked);

    if (isChecked) {
      const allKeys = new Set(filteredAgents.map((_, index) => index + (currentPage - 1) * itemsPerPage));
      setSelectedAgents(allKeys);
    } else {
      setSelectedAgents(new Set());
    }
  };

  const handleDeleteAll = async () => {
    if (selectedAgents.size > 0) {
      const idsToDelete = Array.from(selectedAgents).map(key => filteredAgents[key].id);
      try {
        await Promise.all(idsToDelete.map(id => axios.delete(`http://localhost:8080/agents/${id}`)));
        const updatedAgents = agents.filter(agent => !idsToDelete.includes(agent.id));
        setAgents(updatedAgents);
        setSelectedAgents(new Set());
        setSelectAll(false);
      } catch (error) {
        console.error('Error deleting agents:', error.response ? error.response.data : error.message);
      }
    }
  };

  const handleContextMenuClick = (event, index) => {
    event.preventDefault();
    setSelectedAgentIndex(index);
    setContextMenuAnchor(event.currentTarget);
  };

  const handleContextMenuClose = () => {
    setContextMenuAnchor(null);
  };

  const handleDelete = async () => {
    if (selectedAgentIndex !== null) {
      const agentToDelete = agents[selectedAgentIndex];
      try {
        await axios.delete(`http://localhost:8080/agents/${agentToDelete.id}`);
        const updatedAgents = agents.filter((_, index) => index !== selectedAgentIndex);
        setAgents(updatedAgents);
        setSelectedAgentIndex(null);
      } catch (error) {
        console.error('Error deleting agent:', error.response ? error.response.data : error.message);
      }
      setContextMenuAnchor(null);
    }
  };

  const handleModify = () => {
    if (selectedAgentIndex !== null) {
      const agent = agents[selectedAgentIndex];
      navigate(`/agents/${agent.id}/edit`);  
      setContextMenuAnchor(null);
      setSelectedAgentIndex(null);
    }
  };
  
  

  const filteredAgents = agents.filter(agent => {
    if (!agent) return false;
    const lowerCaseSearch = debouncedSearch.toLowerCase();
    return (
      (selectedGrade.length === 0 || selectedGrade.includes(agent.grade)) &&
      (selectedService.length === 0 || selectedService.includes(agent.service)) &&
      (agent.prenom?.toLowerCase().includes(lowerCaseSearch) ||
      agent.nom?.toLowerCase().includes(lowerCaseSearch) ||
      agent.codeAuth?.toLowerCase().includes(lowerCaseSearch))
    );
  });
  
  

  const totalPages = Math.ceil(filteredAgents.length / itemsPerPage);
  const paginatedAgents = filteredAgents.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const renderPagination = () => {
    const pagination = [];
    const maxVisiblePages = 5;
    
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    if (startPage > 1) {
      pagination.push(
        <span key="start" onClick={() => handlePageChange(1)}>
          1
        </span>
      );
      if (startPage > 2) {
        pagination.push(<span key="start-ellipsis">...</span>);
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      pagination.push(
        <span
          key={i}
          className={currentPage === i ? 'active' : ''}
          onClick={() => handlePageChange(i)}
        >
          {i}
        </span>
      );
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        pagination.push(<span key="end-ellipsis">...</span>);
      }
      pagination.push(
        <span key="end" onClick={() => handlePageChange(totalPages)}>
          {totalPages}
        </span>
      );
    }

    return pagination;
  };

  return (
    <div className="agent-container">
      <div className="top-bar">
        <h2>Agents</h2>
        <div className="admin-info">
          <div className="admin-details">
            <span className="admin-name">Joe Ad</span>
            <span className="admin-role">Admin</span>
          </div>
          <img src={icons.services} alt="Avatar" className="admin-avatar" />
        </div>
      </div>

      <div className="search-and-filter">
  <div className="search-bar-container">
    <TextField
      placeholder="Search here..."
      variant="outlined"
      size="small"
      value={search}
      onChange={handleSearchChange}
      className="search-bar"
      InputProps={{
        startAdornment: <img src={icons.search} alt="Search Icon" className="search-icon" />
      }}
    />
   
  </div>
  
  <div className="filter-and-add">
  {selectAll && (
      <Button
        variant="contained"
        color="error"
        className="delete-all-btn"
        onClick={handleDeleteAll}
      >
        Delete All
      </Button>
    )}
    
    <Button
      variant="outlined"
      className="filter-btn"
      onClick={handleFilterClick}
    >
      Filtrer par <span className="arrow-down">▼</span>
    </Button>
    <Button
      variant="contained"
      color="primary"
      className="add-agent-btn"
      onClick={() => navigate('/agents/ajouteragent')}
    >
      + Ajouter Agent
    </Button>

    <Menu
      anchorEl={anchorEl}
      open={Boolean(anchorEl)}
      onClose={handleFilterClose}
      PaperProps={{ style: { maxHeight: 300 } }}
    >
      <MenuItem disabled>
        <strong>Grade</strong>
      </MenuItem>
      {uniqueGrades.map((grade, index) => (
        <MenuItem key={index} value={grade}>
          <FormControlLabel
            control={
              <MuiCheckbox
                checked={selectedGrade.includes(grade)}
                onChange={handleGradeChange}
                value={grade}
              />
            }
            label={grade}
          />
        </MenuItem>
      ))}

      <MenuItem disabled>
        <strong>Service</strong>
      </MenuItem>
      {uniqueServices.map((service, index) => (
        <MenuItem key={index} value={service}>
          <FormControlLabel
            control={
              <MuiCheckbox
                checked={selectedService.includes(service)}
                onChange={handleServiceChange}
                value={service}
              />
            }
            label={service}
          />
        </MenuItem>
      ))}
    </Menu>
  </div>
</div>

      {error ? (
        <div className="error-message">{error}</div>
      ) : loading ? (
        <div className="loading-message">Loading...</div>
      ) : filteredAgents.length === 0 ? (
        <div className="empty-message">No agents found</div>
      ) : (
        <TableContainer component={Paper} className="agent-table-container">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    checked={selectAll}
                    onChange={handleSelectAllChange}
                    inputProps={{ 'aria-label': 'select all agents' }}
                  />
                </TableCell>
                <TableCell>Code</TableCell>
                <TableCell>Prénom</TableCell>
                <TableCell>Nom</TableCell>
                <TableCell>Grade</TableCell>
                <TableCell>Poste</TableCell>
                <TableCell>Service</TableCell>
                <TableCell>Date d'embauche</TableCell>
                <TableCell>E-mail</TableCell>
                <TableCell>Numero de téléphone</TableCell>
                <TableCell>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedAgents.map((agent, index) => (
                <TableRow key={index}>
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedAgents.has(index + (currentPage - 1) * itemsPerPage)}
                      onChange={() => handleSelectChange(index)}
                    />
                  </TableCell>
                  <TableCell>#{agent.codeAuth}</TableCell>
                  <TableCell>{agent.prenom}</TableCell>
                  <TableCell>{agent.nom}</TableCell>
                  <TableCell>{agent.grade}</TableCell>
                  <TableCell>{agent.post}</TableCell>
                  <TableCell>{agent.service}</TableCell>
                  <TableCell>{agent.date}</TableCell>
                  <TableCell>{agent.email}</TableCell>
                  <TableCell>{agent.telephone}</TableCell>
                  <TableCell>
                    <IconButton onClick={(event) => handleContextMenuClick(event, index)}>
                      ...
                    </IconButton>
                    <Menu
                      anchorEl={contextMenuAnchor}
                      open={Boolean(contextMenuAnchor)}
                      onClose={handleContextMenuClose}
                    >
                      <MenuItem onClick={handleModify}>Modify</MenuItem>
                      <MenuItem onClick={handleDelete}>Delete</MenuItem>
                    </Menu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <div className="pagination">{renderPagination()}</div>
    </div>
  );
};

export default Agent;
