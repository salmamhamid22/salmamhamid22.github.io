import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TextField,
  Menu,
  MenuItem,
  IconButton,
  Button,
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import FilterListIcon from '@mui/icons-material/FilterList';
import { useNavigate } from 'react-router-dom';
import icons from '../importAllSvg';
import './Candidatures.css'; // Make sure this import is correct

const Candidature = () => {
  const [candidatures, setCandidatures] = useState([]);
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedCandidature, setSelectedCandidature] = useState(null);
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [filters, setFilters] = useState({
    statut: '',
    sexe: '',
  });

  const itemsPerPage = 7;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCandidatures = async () => {
      try {
        const response = await axios.get('http://localhost:8080/candidatures');
        setCandidatures(response.data);
      } catch (error) {
        console.error('Error fetching candidatures:', error);
      }
    };

    fetchCandidatures();
  }, []);

  const handleSearchChange = (event) => {
    setSearch(event.target.value);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleMenuClick = (event, candidature) => {
    event.stopPropagation(); // Prevent the row click event
    setAnchorEl(event.currentTarget);
    setSelectedCandidature(candidature);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedCandidature(null);
  };

  const changeStatus = async (status) => {
    if (selectedCandidature) {
      try {
        await axios.patch(`http://localhost:8080/candidatures/${selectedCandidature.id}`, {
          statut: status,
        });
        setCandidatures((prev) =>
          prev.map((c) =>
            c.id === selectedCandidature.id ? { ...c, statut: status } : c
          )
        );
      } catch (error) {
        console.error('Error updating status:', error);
      }
      handleMenuClose();
    }
  };

  const getStatusClass = (statut) => {
    switch (statut) {
      case 'ADMIS':
        return 'status-admis';
      case 'NON_ADMIS':
        return 'status-non-admis';
      case 'EN_ATTENTE':
        return 'status-en-attente';
      default:
        return '';
    }
  };

  const filteredCandidatures = candidatures
    .filter((candidature) =>
      (candidature.prenom.toLowerCase().includes(search.toLowerCase()) ||
      candidature.nom.toLowerCase().includes(search.toLowerCase())) &&
      (!filters.statut || candidature.statut === filters.statut) &&
      (!filters.sexe || candidature.sexe === filters.sexe)
    );

  const totalPages = Math.ceil(filteredCandidatures.length / itemsPerPage);
  const paginatedCandidatures = filteredCandidatures.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleFilterMenuClick = (event) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterMenuClose = () => {
    setFilterAnchorEl(null);
  };

  const applyFilters = (filter) => {
    setFilters(filter);
    handleFilterMenuClose();
  };

  return (
    <div className="candidate-container">
      <div className="top-bar">
        <h2>Candidatures</h2>
        <div className="admin-info">
          <div className="admin-details">
            <span className="admin-name">Joe Ad</span>
            <span className="admin-role">Admin</span>
          </div>
          <img src={icons.services} alt="Avatar" className="admin-avatar" />
        </div>
      </div>
      <div className="search-bar-container">
        <TextField
          placeholder="Search here..."
          variant="outlined"
          size="small"
          value={search}
          onChange={handleSearchChange}
          className="search-bar"
          InputProps={{
            startAdornment: <img src={icons.search} alt="Search Icon" className="search-icon" />,
          }}
        />
        <Button
          variant="contained"
          color="primary"
          onClick={handleFilterMenuClick}
          className="filter-button"
        >
          Filtrer par <span className="arrow-down">▼</span>
        </Button>
      </div>
      <TableContainer component={Paper} className="candidate-table">
        <Table>
          <TableHead>
            <TableRow>
              {['Id', 'Prénom', 'Nom', 'Email', 'Date de Naissance', 'Diplôme', 'Sexe', 'Poste Postulé', 'Statut', 'Actions'].map((header, index) => (
                <TableCell key={index}>{header}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedCandidatures.map((candidature) => (
              <TableRow key={candidature.id}>
                <TableCell>#{candidature.id}</TableCell>
                <TableCell>{candidature.prenom}</TableCell>
                <TableCell>{candidature.nom}</TableCell>
                <TableCell>{candidature.email}</TableCell>
                <TableCell>{candidature.dateNaissance}</TableCell>
                <TableCell>{candidature.diplome}</TableCell>
                <TableCell>{candidature.sexe}</TableCell>
                <TableCell>{candidature.postePostule}</TableCell>
                <TableCell className={getStatusClass(candidature.statut)}>
                  {candidature.statut}
                </TableCell>
                <TableCell>
                  <IconButton onClick={(event) => handleMenuClick(event, candidature)}>
                    <MoreVertIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={() => changeStatus('ADMIS')}>Admis</MenuItem>
        <MenuItem onClick={() => changeStatus('NON_ADMIS')}>Non Admis</MenuItem>
        <MenuItem onClick={() => changeStatus('EN_ATTENTE')}>En Attente</MenuItem>
      </Menu>
      <Menu
        anchorEl={filterAnchorEl}
        open={Boolean(filterAnchorEl)}
        onClose={handleFilterMenuClose}
      >
        <MenuItem onClick={() => applyFilters({ statut: 'ADMIS' })}>Statut: Admis</MenuItem>
        <MenuItem onClick={() => applyFilters({ statut: 'NON_ADMIS' })}>Statut: Non Admis</MenuItem>
        <MenuItem onClick={() => applyFilters({ statut: 'EN_ATTENTE' })}>Statut: En Attente</MenuItem>
        <MenuItem onClick={() => applyFilters({ sexe: 'Masculin' })}>Sexe: Masculin</MenuItem>
        <MenuItem onClick={() => applyFilters({ sexe: 'Feminin' })}>Sexe: Feminin</MenuItem>
        <MenuItem onClick={() => applyFilters({ statut: '', sexe: '' })}>Reset Filters</MenuItem>
      </Menu>
      <div className="pagination">
        <span
          className="arrow"
          onClick={() => handlePageChange(currentPage - 1)}
          style={{ visibility: currentPage === 1 ? 'hidden' : 'visible' }}>
          {'<'}
        </span>
        {Array.from({ length: totalPages }, (_, i) => (
          <span
            key={i}
            className={currentPage === i + 1 ? 'active' : ''}
            onClick={() => handlePageChange(i + 1)}>
            {i + 1}
          </span>
        ))}
        <span
          className="arrow"
          onClick={() => handlePageChange(currentPage + 1)}
          style={{ visibility: currentPage === totalPages ? 'hidden' : 'visible' }}>
          {'>'}
        </span>
      </div>
    </div>
  );
};

export default Candidature;
