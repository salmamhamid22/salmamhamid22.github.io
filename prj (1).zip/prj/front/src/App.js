import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import useDisableZoom from './DisableZoom';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard/Dashboard';
import Agents from './components/Agents/Agents';
import AddAgent from './components/AddAgent/AddAgent';
import Services from './components/Services/Services';
import Commissions from './components/Commissions/Commissions';
import AjouterCommission from './components/AjouterCommission/AjouterCommission';
import Calendrier from './components/Calendrier/Calendrier';
import CandidateList from './components/Candidatures/Candidatures';
import AfficherCommission from './components/AfficherCommission/AfficherCommission';
import CandidaturesDetail from './components/CandidaturesDetail/CandidaturesDetail';
import Convocation from './components/Convocation/Convocation'; 
import Besoins from './components/Besoins/Besoins';
import Listes from './components/Listes/Listes'; 
import ListesDetails from './components/ListesDetails/ListesDetails';
import Avis from './components/Avis/Avis';  
import AvisDetails from './components/AvisDetails/AvisDetails';  
import Epreuve from './components/Epreuve/Epreuve';  
import EditAgent from './components/EditAgent/EditAgent';
import EpreuveDetails from './components/EpreuveDetails/EpreuveDetails'; 
import Profile from './components/Profile/Profile';
import LoginRegister from './components/LoginRegister/LoginRegister';
import AddService from './components/AddService/AddService';
import AddBesoin from './components/AddBesoin/AddBesoin';

import MenuIcon from '@mui/icons-material/Menu';


function App() {
    useDisableZoom();
    const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 1300);
    const [windowWidth, setWindowWidth] = useState(window.innerWidth);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [userRole, setUserRole] = useState('');

    useEffect(() => {
        function handleResize() {
            setWindowWidth(window.innerWidth);
            if (window.innerWidth > 1300) {
                setIsSidebarOpen(true);
            } else {
                setIsSidebarOpen(false);
            }
        }

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const handleLogin = (role) => {
        setUserRole(role);
        setIsLoggedIn(true);
    };

    const redirectPath = () => {
        switch (userRole) {
            case 'ROLE_ADMIN':
                return '/dashboard';
            case 'ROLE_DIRECTEUR':
                return '/directeur-dashboard';
            case 'ROLE_CHEFSERVICE':
                return '/chefservice-dashboard';
            case 'ROLE_EMPLOYE':
                return '/employe-dashboard';
            case 'ROLE_MEMBRE':
                return '/membre-dashboard';
            default:
                return '/';
        }
    };

    return (
        <Router>
            {isLoggedIn ? (
                <Layout isSidebarOpen={isSidebarOpen} toggleSidebar={toggleSidebar}>
                    <Routes>
                        <Route path="/login" element={<LoginRegister />} />
                        <Route path="/dashboard" element={<Dashboard />} />
                        <Route path="/agents" element={<Agents />} />
                        <Route path="/agents/ajouteragent" element={<AddAgent />} />
                        <Route path="/services" element={<Services />} />
                        <Route path="/commissions" element={<Commissions />} />
                        <Route path="/commissions/ajoutercommission" element={<AjouterCommission />} />
                        <Route path="/calendrier" element={<Calendrier />} />
                        <Route path="/candidatures" element={<CandidateList />} />
                        <Route path="/candidaturesdetail/:id" element={<CandidaturesDetail />} />
                        <Route path="/affichercommission/:name" element={<AfficherCommission />} />
                        <Route path="/convocations" element={<Convocation />} />
                        <Route path="/besoins" element={<Besoins />} />
                        <Route path="/listes" element={<Listes />} />
                        <Route path="/listesdetails/:id" element={<ListesDetails />} />
                        <Route path="/avis" element={<Avis />} />
                        <Route path="/avisdetails" element={<AvisDetails />} />
                        <Route path="/epreuve" element={<Epreuve />} />
                        <Route path="/epreuvedetails" element={<EpreuveDetails />} />
                        <Route path="/profile" element={<Profile />} />
                        <Route path="/agents/:id/edit" element={<EditAgent />} />
                        <Route path="/services/ajouterservice" element={<AddService />} />
                        <Route path="/create-besoin" element={<AddBesoin />} />


                    </Routes>
                </Layout>
            ) : (
                <Routes>
                    <Route
                        path="/"
                        element={<LoginRegister onLogin={handleLogin} />}
                    />
                    <Route path="*" element={<Navigate to="/" />} />
                </Routes>
            )}
            {windowWidth <= 1300 && isLoggedIn && (
                <button className="btn btn-primary mt-3 ml-3" onClick={toggleSidebar}>
                    <MenuIcon />
                </button>
            )}
        </Router>
    );
}

export default App;
