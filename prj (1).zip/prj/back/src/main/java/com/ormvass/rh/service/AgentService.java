package com.ormvass.rh.service;

import com.ormvass.rh.model.Admin;
import com.ormvass.rh.model.Agent;
import com.ormvass.rh.model.Chefservice;
import com.ormvass.rh.model.Directeur;
import com.ormvass.rh.model.Employe;
import com.ormvass.rh.model.Membre;
import com.ormvass.rh.repository.AgentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AgentService {

    @Autowired
    private AgentRepository agentRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder; // For password hashing and comparison

    public List<Agent> getAllAgents() {
        return agentRepository.findAll();
    }

    public Optional<Agent> getAgentById(Long id) {
        return agentRepository.findById(id);
    }
    
    public Optional<Agent> getAgentByCodeAuth(String codeAuth) {
        return agentRepository.findByCodeAuth(codeAuth);
    }

    public Agent saveAgent(Agent agent) {
        System.out.println("Saving agent: " + agent);
        return agentRepository.save(agent);
    }

    public void deleteAgent(Long id) {
        System.out.println("Deleting agent with ID: " + id);
        agentRepository.deleteById(id);
    }

    // Method to create or update an Agent
    public Agent createOrUpdateAgent(Agent agent) {
        if (agent == null) {
            throw new IllegalArgumentException("Agent cannot be null");
        }
        System.out.println("Creating or updating agent: " + agent);
        return agentRepository.save(agent);
    }

    // Method to handle creating or updating an Agent based on role type
    public Agent createRole(String roleType, Agent agent) {
        if (agent == null) {
            throw new IllegalArgumentException("Agent cannot be null");
        }

        // Ensure agent type matches the role type
        switch (roleType) {
            case "Admin":
                if (agent instanceof Admin) {
                    return createOrUpdateAgent(agent);
                }
                break;
            case "Directeur":
                if (agent instanceof Directeur) {
                    return createOrUpdateAgent(agent);
                }
                break;
            case "Chefservice":
                if (agent instanceof Chefservice) {
                    return createOrUpdateAgent(agent);
                }
                break;
            case "Membre":
                if (agent instanceof Membre) {
                    return createOrUpdateAgent(agent);
                }
                break;
            case "Employe":
                if (agent instanceof Employe) {
                    return createOrUpdateAgent(agent);
                }
                break;
            default:
                throw new IllegalArgumentException("Invalid role type: " + roleType);
        }

        throw new IllegalArgumentException("Agent type does not match role type: " + roleType);
    }

    // Manage agent based on admin's role
    public void manageAgent(Admin admin, Agent agent) {
        if (admin == null) {
            throw new IllegalArgumentException("Admin cannot be null");
        }
        if (agent == null) {
            throw new IllegalArgumentException("Agent cannot be null");
        }

        String roleType = determineRoleType(agent);
        createRole(roleType, agent);
    }

    private String determineRoleType(Agent agent) {
        // Determine role type based on agent instance
        if (agent instanceof Admin) return "Admin";
        if (agent instanceof Directeur) return "Directeur";
        if (agent instanceof Chefservice) return "Chefservice";
        if (agent instanceof Employe) return "Employe";
        if (agent instanceof Membre) return "Membre";
        throw new IllegalArgumentException("Unknown agent type");
    }

    // Authenticate an agent based on codeAuth and password
    public Agent authenticate(String codeAuth, String password) {
        Optional<Agent> optionalAgent = getAgentByCodeAuth(codeAuth);
        if (optionalAgent.isPresent()) {
            Agent agent = optionalAgent.get();
            if (passwordEncoder.matches(password, agent.getPassword())) {
                return agent;
            }
        }
        return null; // Authentication failed
    }
}
