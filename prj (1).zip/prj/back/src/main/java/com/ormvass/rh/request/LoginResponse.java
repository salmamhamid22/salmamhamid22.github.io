package com.ormvass.rh.request;

public class LoginResponse {
    private String role;

    // Constructor
    public LoginResponse(String role) {
        this.role = role;
    }

    // Getter
    public String getRole() {
        return role;
    }

    // Setter
    public void setRole(String role) {
        this.role = role;
    }
}

