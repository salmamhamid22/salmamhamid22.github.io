package com.ormvass.rh.request;

import com.ormvass.rh.model.Document;

public class DocumentValidationRequest {
    private Document document;

    // Constructors
    public DocumentValidationRequest() {}

    public DocumentValidationRequest(Document document) {
        this.document = document;
    }

    // Getters and setters
    public Document getDocument() {
        return document;
    }

    public void setDocument(Document document) {
        this.document = document;
    }
}
