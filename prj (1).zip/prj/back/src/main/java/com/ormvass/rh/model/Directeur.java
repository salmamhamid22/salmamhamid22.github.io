package com.ormvass.rh.model;

import jakarta.persistence.*;


@Entity
@Table(name = "directeur")  // Table for common attributes
public class Directeur extends Agent {
    private String directorSpecificField; // Add director-specific fields here

    // Getters and setters
}
