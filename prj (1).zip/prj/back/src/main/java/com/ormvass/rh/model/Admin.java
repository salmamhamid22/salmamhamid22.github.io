package com.ormvass.rh.model;

import java.io.Serializable;
import jakarta.persistence.*;

@Entity
@Table(name = "admin")  // Table for common attributes
public class Admin extends Agent {
    private String adminSpecificField; // Add admin-specific fields here

    // Getters and setters
}

