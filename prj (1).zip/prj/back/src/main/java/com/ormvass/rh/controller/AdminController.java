package com.ormvass.rh.controller;

import com.ormvass.rh.model.Admin;
import com.ormvass.rh.model.Agent;
import com.ormvass.rh.request.UserManagementRequest;
import com.ormvass.rh.service.AgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/admins")
public class AdminController {

    @Autowired
    private AgentService agentService;

    @PostMapping("/manage-users")
    public ResponseEntity<?> manageUsers(@RequestBody UserManagementRequest request) {
        Admin admin = getAuthenticatedAdmin();
        if (admin == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
        }

        Agent agent = request.getAgent();
        if (agent == null) {
            return ResponseEntity.badRequest().body("Agent information is missing");
        }

        try {
            agentService.manageAgent(admin, agent);
            return ResponseEntity.ok("User managed successfully");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/delete-agent/{id}")
    public ResponseEntity<?> deleteAgent(@PathVariable Long id) {
        Admin admin = getAuthenticatedAdmin();
        if (admin == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
        }

        Optional<Agent> agent = agentService.getAgentById(id);
        if (agent.isPresent()) {
            agentService.deleteAgent(id);
            return ResponseEntity.ok("Agent deleted successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Agent not found");
        }
    }

    private Admin getAuthenticatedAdmin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof Admin) {
            return (Admin) authentication.getPrincipal();
        }
        return null;
    }
}
