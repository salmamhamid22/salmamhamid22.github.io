package com.ormvass.rh.service;

import com.ormvass.rh.model.Chefservice;
import com.ormvass.rh.model.Besoin;
import com.ormvass.rh.repository.BesoinRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChefserviceService {

    @Autowired
    private BesoinRepository besoinRepository;

    public void createBesoin(Chefservice chefservice, Besoin besoin) {
        
        besoinRepository.save(besoin);
    }
}
