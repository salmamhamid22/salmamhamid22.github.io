package com.ormvass.rh.request;

import com.ormvass.rh.model.Agent;

public class UserManagementRequest {
    private Agent agent; // Update the field type to Agent

    // Constructors
    public UserManagementRequest() {}

    public UserManagementRequest(Agent agent) {
        this.agent = agent;
    }

    // Getters and setters
    public Agent getAgent() {
        return agent;
    }

    public void setAgent(Agent agent) {
        this.agent = agent;
    }
}
