package com.ormvass.rh.request;

public class LoginRequest {
    private String password;
    private String codeAuth; // Updated field name

    // Constructors
    public LoginRequest() {}

    public LoginRequest(String password, String codeAuth) {
        this.password = password;
        this.codeAuth = codeAuth;
    }

    // Getters and setters
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCodeAuth() {
        return codeAuth;
    }

    public void setCodeAuth(String codeAuth) {
        this.codeAuth = codeAuth;
    }
}
