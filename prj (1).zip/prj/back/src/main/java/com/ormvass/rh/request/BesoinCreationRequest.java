package com.ormvass.rh.request;

import com.ormvass.rh.model.Besoin;

public class BesoinCreationRequest {
    private Besoin besoin;

    // Constructors
    public BesoinCreationRequest() {}

    public BesoinCreationRequest(Besoin besoin) {
        this.besoin = besoin;
    }

    // Getters and setters
    public Besoin getBesoin() {
        return besoin;
    }

    public void setBesoin(Besoin besoin) {
        this.besoin = besoin;
    }
}
