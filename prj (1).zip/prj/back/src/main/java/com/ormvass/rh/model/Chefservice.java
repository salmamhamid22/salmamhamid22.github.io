package com.ormvass.rh.model;

import jakarta.persistence.*;


@Entity
@Table(name = "chefservice")  // Table for common attributes
 public class Chefservice extends Agent {
    private String chefserviceSpecificField; // Add manager-specific fields here

    // Getters and setters
}
