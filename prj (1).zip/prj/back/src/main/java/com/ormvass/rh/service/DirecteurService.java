package com.ormvass.rh.service;

import com.ormvass.rh.model.Directeur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ormvass.rh.model.Document;
import com.ormvass.rh.repository.DocumentRepository;
 

@Service
public class DirecteurService {

    @Autowired
    private DocumentRepository documentRepository;

    public void validateDocument(Directeur directeur, Document document) {
        // Retrieve the document from the repository
        Document existingDocument = documentRepository.findById(document.getId())
            .orElseThrow(() -> new IllegalArgumentException("Document not found"));

        // Update the document's status
        existingDocument.setStatus("approved"); // or any logic for validation
        documentRepository.save(existingDocument);
    }
}
