package com.ormvass.rh.controller;
 
import com.ormvass.rh.model.Admin;
import com.ormvass.rh.model.Agent;
import com.ormvass.rh.model.Chefservice;
import com.ormvass.rh.model.Directeur;
import com.ormvass.rh.model.Employe;
import com.ormvass.rh.model.Membre;
import com.ormvass.rh.request.LoginRequest;
import com.ormvass.rh.request.LoginResponse;
import com.ormvass.rh.service.AgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class LoginController {

    @Autowired
    private AgentService agentService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        Agent agent = agentService.authenticate(
            loginRequest.getPassword(),
            loginRequest.getCodeAuth() // Updated field
        );

        if (agent == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }

        // Determine role
        String role = determineRole(agent);
        
        return ResponseEntity.ok(new LoginResponse(role));
    }

    private String determineRole(Agent agent) {
        if (agent instanceof Admin) return "Admin";
        if (agent instanceof Directeur) return "Directeur";
        if (agent instanceof Chefservice) return "Chefservice";
        if (agent instanceof Employe) return "Employe";
        if (agent instanceof Membre) return "Membre";
        return "Unknown";
    }
}
