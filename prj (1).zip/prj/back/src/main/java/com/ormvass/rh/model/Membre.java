package com.ormvass.rh.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Membre extends Agent {
    private String membreSpecificField; // Add manager-specific fields here

    // Getters and setters
}
