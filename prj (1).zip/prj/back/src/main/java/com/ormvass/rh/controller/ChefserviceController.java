package com.ormvass.rh.controller;

import com.ormvass.rh.model.Chefservice;
import com.ormvass.rh.model.Besoin;
import com.ormvass.rh.request.BesoinCreationRequest;
import com.ormvass.rh.service.ChefserviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/chefservices")
public class ChefserviceController {

    @Autowired
    private ChefserviceService chefserviceService;

    @PostMapping("/create-besoins")
    public ResponseEntity<?> createBesoin(@RequestBody BesoinCreationRequest request) {
        Chefservice chefservice = getAuthenticatedChefservice();
        if (chefservice == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
        }

        Besoin besoin = request.getBesoin();
        if (besoin == null) {
            return ResponseEntity.badRequest().body("Besoin information is missing");
        }

        try {
            chefserviceService.createBesoin(chefservice, besoin);
            return ResponseEntity.ok("Besoin created successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error creating besoin: " + e.getMessage());
        }
    }

    private Chefservice getAuthenticatedChefservice() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof Chefservice) {
            return (Chefservice) authentication.getPrincipal();
        }
        return null;
    }
}
