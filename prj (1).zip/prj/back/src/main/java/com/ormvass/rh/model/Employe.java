package com.ormvass.rh.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table; 

@Entity
@Table(name = "employe")  // Table for common attributes
public class Employe extends Agent {
    private String employeSpecificField; // Add employee-specific fields here

    // Getters and setters
}
